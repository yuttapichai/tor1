﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.IO;
using System.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Boolean flag = false,flag_slide_chk = false,flag_continue_chk = false,flag_pulse = false,flag_linear = false;
        int count = 0;
        StringComparer stringComparer = StringComparer.OrdinalIgnoreCase;
        SerialPort port;
        String rotate, read_txt, sendData;
        int resolution,gearbox,read_data_round_chk=0;
        Boolean connect_btn_flag = true;
        String com_name_copy = "COM";
        String[] read;
        float lead_screw =0, linear_encoder = 0, error;
        int continue_motor;
        public MainWindow()
        {


            InitializeComponent();
            start_btn.Click += startClick;
            connect_btn.Click += connClick;
            ext_btn.Click += exitClick;
            comport_check();
            start_btn.IsEnabled = false;

            //pls_mcu.IsEnabled = false;
            //percenterror.IsEnabled = false;
            //encoder.IsEnabled = false;
            
            //set text field
            distance_pulse.IsEnabled = false;
            start_vel_pulse.IsEnabled = false;
            speed_pulse.IsEnabled = false;

            //set slide initial

            degree_slide.Foreground = Brushes.Green;
            degree_slide.FontWeight = FontWeights.Bold;
        }

        void startClick(object sender, RoutedEventArgs e)
        {   
            flag_continue_chk = true;
            //MessageBox.Show("Message here");
            //this.Close();
            try
            {
                if (cw_rotate.IsChecked == true)
                {
                    rotate = "1";
                }
                else if (ccw_rotate.IsChecked == true)
                {
                    rotate = "0";
                }
                
                resolution = Int32.Parse(resolution_txt.Text);
                gearbox = int.Parse(gearbox_txt.Text);
                String runtime_txt = runtime_motor.Text;
                String acc_txt = acc.Text;
                String speed_txt = speed.Text;

                String distance_pulse_txt = distance_pulse.Text;
                String start_vel_pulse_txt = start_vel_pulse.Text;
                String speed_pulse_txt = speed_pulse.Text;
                String lead_crew_txt = lead_crew_ui.Text;


                if (!flag_slide_chk)
                {
                    sendData = degree2pulse(Int32.Parse(acc_txt)).ToString() + "," + rpm2period(float.Parse(speed_txt)).ToString() + "," + rotate + "," + degree2pulse(Int32.Parse(runtime_txt)).ToString();
                }
                else if (flag_slide_chk)
                {
                    sendData = start_vel_pulse_txt + "," + speed_pulse_txt + "," + rotate + "," + distance_pulse_txt;
                }
                decimal a = Decimal.Parse(sendData);

                while (flag_continue_chk)
                {
                    if (continue_rd_btn.IsChecked == true)
                    {
                        continue_motor = int.Parse(continue_txt.Text);
                    }

                    for (int i = 0 ; i < continue_motor; i++)
                    {
                        Console.WriteLine("round : "+continue_motor);
                        //MessageBox.Show(a.ToString());
                        Console.WriteLine(sendData);
                        port.Write(sendData);
                        flag = true;  //flag for read data

                        while (flag) //read data from serial port loop
                        {

                            read_txt = port.ReadLine();
                            if (stringComparer.Equals("END\r", read_txt))
                            {
                                //status.Background = Brushes.Red;
                                //Console.WriteLine(read_txt);
                                flag = false;
                            }
                            else if (stringComparer.Equals("START\r", read_txt))
                            {
                                Console.WriteLine("Start");
                                //status.Background = Brushes.Green;
                            }
                            else if(stringComparer.Equals("PULSE\r", read_txt))
                            {
                                flag_pulse = true;
                            }
                            else if (stringComparer.Equals("LINEAR\r", read_txt))
                            {
                                flag_linear = true;
                            }
                            else
                            {
                                read = read_txt.Split('\r');
                                Console.WriteLine(read[0]);
                                //if (read_data_round_chk == 8)
                                if (flag_pulse)
                                {
                                    String aa = (pulse2distance((resolution * gearbox), float.Parse(lead_crew_txt), float.Parse(read[0]))).ToString();//set variable from lead screw signal in mm.
                                    
                                    lead_screw += float.Parse(aa);
                                    pls_mcu.Text = lead_screw.ToString(); //show distance of lead screw
                                    flag_pulse = false;

                                }
                                //else if (read_data_round_chk == 10)
                                else if (flag_linear)
                                {

                                    String aa = (pulse2distance((resolution * gearbox), float.Parse(lead_crew_txt), float.Parse(read[0]))).ToString(); //set variable from linear encoder signal in mm.
                                    
                                    linear_encoder += float.Parse(aa);
                                    encoder.Text = linear_encoder.ToString(); //show distance of linear encoder
                                    flag_linear = false;

                                }
                                read_data_round_chk++;
                            }
                        }
                        Console.WriteLine("continue : " + continue_motor);
                    }
                    Console.WriteLine("lead scerw "+ lead_screw+" linear "+ linear_encoder);
                    Console.WriteLine("Exit if condition");
                    flag_continue_chk = false;
                }
                try
                {
                    error = (((linear_encoder - lead_screw) / lead_screw) * 100);
                    percenterror.Text = Math.Abs(error).ToString();
                    lead_screw = linear_encoder = error = 0;

                }
                catch (Exception E)
                {
                    percenterror.Text = "error";
                }
                read_data_round_chk = 0;
            }
            catch (FormatException w)
            {
                acc.IsEnabled = true;
                speed.IsEnabled = true;
                MessageBox.Show(w.ToString(), "Error");
            }
        }

/****************************************************************
 *function for connect serial port
 ***************************************************************/
        void connClick(object sender, RoutedEventArgs e)
        {
            ComboBoxItem br_typeItem = (ComboBoxItem)baudrate.SelectedItem;
            ComboBoxItem sp_typeItem = (ComboBoxItem)serialport.SelectedItem;

            string buadrate_combo_txt = br_typeItem.Content.ToString();
            string serialport_combo_txt = sp_typeItem.Content.ToString();
            if (connect_btn_flag)
            {
                try
                {
                    //port = new SerialPort(com_port.Text, int.Parse(baud_rate.Text), Parity.None, 8, StopBits.One);
                    port = new SerialPort(serialport_combo_txt, int.Parse(buadrate_combo_txt), Parity.None, 8, StopBits.One);
                    port.Open();

                    baudrate.IsEnabled = false;
                    serialport.IsEnabled = false;
                    //connect_btn.IsEnabled = false;
                    start_btn.IsEnabled = true;

                    connect_btn.Content = "Disconnect";
                    connect_btn_flag = false;
                }
                catch (Exception err)
                {
                    connect_btn.IsEnabled = true;
                    MessageBox.Show(err.ToString(), "Error");
                }
            }
            else
            {
                port.Close();
                baudrate.IsEnabled = true;
                serialport.IsEnabled = true;
                //connect_btn.IsEnabled = true;
                start_btn.IsEnabled = false;
                connect_btn.Content = "Connect";
                connect_btn_flag = true;
            }
            

        }

/****************************************************************
* function for close the program
***************************************************************/
        void exitClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
/****************************************************************
* function for detect serial port availble
***************************************************************/
        void comport_check()
        {
            String[] portname = SerialPort.GetPortNames();
            
            //MessageBox.Show(portname[1].ToString());
            for (int i = 0; i < portname.Length; i++)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = portname[i].ToString();
                
                if(com_name_copy != portname[i].ToString())
                {
                    com_name_copy = portname[i].ToString();
                    serialport.Items.Add(item);
                }
                
            }

        }

        private void slide_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void continue_rd_btn_Checked(object sender, RoutedEventArgs e)
        {
            flag_continue_chk = true;
            continue_txt.IsEnabled = true;
            
        }


        private void single_txt_Checked(object sender, RoutedEventArgs e)
        {
            flag_continue_chk = true;
            continue_motor = 1;

            continue_txt.IsEnabled = false;
        }

/****************************************************************
* function for change type data for send to arduino 
*****************************************************************/
        private void slide_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if(e.NewValue == 1)
            {
                degree_slide.FontWeight = FontWeights.Regular;
                pulse_slide.FontWeight = FontWeights.Bold;
                degree_slide.Foreground = Brushes.Black;
                pulse_slide.Foreground = Brushes.Green;

                flag_slide_chk = true;

                distance_pulse.IsEnabled = true;
                start_vel_pulse.IsEnabled = true;
                speed_pulse.IsEnabled = true;

                runtime_motor.IsEnabled = false;
                acc.IsEnabled = false;
                speed.IsEnabled = false;
            }else if (e.NewValue == 0)
            {
                degree_slide.FontWeight = FontWeights.Bold;
                pulse_slide.FontWeight = FontWeights.Regular;
                degree_slide.Foreground = Brushes.Green;
                pulse_slide.Foreground = Brushes.Black;

                flag_slide_chk = false;

                runtime_motor.IsEnabled = true;
                acc.IsEnabled = true;
                speed.IsEnabled = true;

                distance_pulse.IsEnabled = false;
                start_vel_pulse.IsEnabled = false;
                speed_pulse.IsEnabled = false;
            }
        }
/****************************************************************
* function for close the program when press 'ESC' button
***************************************************************/
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }
/*************************************************************************************
* function for add serial port names if user connect serial port after openned program
**************************************************************************************/
        private void serialport_MouseEnter(object sender, MouseEventArgs e)
        {
            comport_check();     
        }
        private void connect_btn_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine("dddd");
        }
/****************************************************************
* function for convert degree to pulse
***************************************************************/
        Int32 degree2pulse(float deg)
        {
            float step = 360.0f / (resolution * gearbox);
            Int32 n = (int)(Math.Round(deg / step));
            return n;
        }
/****************************************************************
* function for convert velocity (rpm) to period (us)
***************************************************************/
        Int32 rpm2period(float rpm)
        {
            //Int32 period = (int)((60.0f / rpm) * (1e6 / (resolution)));
            Int32 period = (int)((60.0f / rpm) * (1e6 / (resolution * gearbox)));
            //Console.WriteLine(period);
            //Int32 n = (int)(Math.Round(period));
            return period;
        }
/****************************************************************
* function for calculate distance (mm.)
***************************************************************/
        float pulse2distance(float res , float lead_screw, float pulse)
        {
            float length = (lead_screw * pulse) / res;
            return length;
        }

    }

}
